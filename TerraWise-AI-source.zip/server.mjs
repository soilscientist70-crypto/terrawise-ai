import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';

const port = Number(process.env.TERRAWISE_PORT || 4173);
const model = process.env.TERRAWISE_OLLAMA_MODEL;
const host = '127.0.0.1';
const origin = `http://${host}:${port}`;
const files = new Map([
  ['/', ['index.html', 'text/html']],
  ['/index.html', ['index.html', 'text/html']],
  ['/styles.css', ['styles.css', 'text/css']],
  ['/soil.js', ['soil.js', 'text/javascript']],
  ['/app.js', ['app.js', 'text/javascript']]
]);
function json(res, code, data) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}

async function interpret(req, res) {
  if (!model) return json(res, 503, { error: 'Start the local server with TERRAWISE_OLLAMA_MODEL set to enable drafts.' });
  if (req.headers.origin !== origin || !/^application\/json(?:;|$)/i.test(req.headers['content-type'] ?? '')) {
    return json(res, 403, { error: 'Open the workspace at the local address printed by the server.' });
  }
  const chunks = [];
  let length = 0;
  for await (const chunk of req.iterator({ destroyOnReturn: false })) {
    length += chunk.length;
    if (length > 16000) {
      req.resume();
      return json(res, 413, { error: 'Interpretation request is too large.' });
    }
    chunks.push(chunk);
  }
  let prompt;
  try { ({ prompt } = JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
  catch { return json(res, 400, { error: 'Expected a JSON prompt.' }); }
  if (typeof prompt !== 'string' || !prompt.trim()) return json(res, 400, { error: 'Prompt is required.' });
  try {
    const response = await fetch('http://127.0.0.1:11434/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: AbortSignal.timeout(120_000),
      body: JSON.stringify({ model, prompt, stream: false, options: { num_predict: 600 } })
    });
    if (!response.ok) throw new Error('Model request failed.');
    const result = await response.json();
    if (typeof result.response !== 'string' || !result.response.trim()) throw new Error('Model returned an empty draft.');
    return json(res, 200, { text: result.response.trim().slice(0, 8000) });
  } catch {
    return json(res, 502, { error: 'The draft could not be generated. Check that Ollama is running and the configured model is available.' });
  }
}

createServer(async (req, res) => {
  if (req.headers.host !== `${host}:${port}`) return json(res, 403, { error: 'Use the printed loopback address.' });
  const route = new URL(req.url, origin).pathname;
  try {
    if (req.method === 'POST' && route === '/api/interpret') return await interpret(req, res);
    if (req.method !== 'GET') return json(res, 405, { error: 'Method unavailable.' });
    if (route === '/api/status') return json(res, 200, { enabled: Boolean(model) });
    const file = files.get(route);
    if (!file) return json(res, 404, { error: 'Page unavailable.' });
    const [name, type] = file;
    const data = await readFile(new URL(name, import.meta.url));
    res.writeHead(200, { 'Content-Type': `${type}; charset=utf-8`, 'X-Content-Type-Options': 'nosniff' });
    res.end(data);
  } catch {
    if (!res.headersSent) json(res, 500, { error: 'Workspace request failed.' });
  }
}).listen(port, host, () => console.log(`TerraWise AI · ${origin} · model ${model ? 'configured' : 'disabled'}`));

const { test } = require('node:test');
const assert = require('node:assert/strict');
const { texture, gradation, atterberg, screen, parseCSV } = require('./soil.js');

test('all 12 USDA primary classes match NRCS triangle reference compositions', () => {
  for (const [s,l,c,name] of [
    [92,5,3,'Sand'],[82,12,6,'Loamy sand'],[65,25,10,'Sandy loam'],
    [42,38,20,'Loam'],[25,60,15,'Silt loam'],[8,87,5,'Silt'],
    [60,15,25,'Sandy clay loam'],[34,34,32,'Clay loam'],[10,55,35,'Silty clay loam'],
    [54,6,40,'Sandy clay'],[10,46,44,'Silty clay'],[20,30,50,'Clay']
  ]) assert.equal(texture(s,l,c).label,name);
});
test('texture boundaries and input validation', () => {
  for (const [s,l,c,name] of [
    [85,15,0,'Loamy sand'],[70,30,0,'Sandy loam'],[52,41,7,'Loam'],[52.1,40.9,7,'Sandy loam'],
    [45,28,27,'Clay loam'],[20,53,27,'Silty clay loam'],[20,40,40,'Silty clay'],
    [45,20,35,'Clay loam'],[45.1,19.9,35,'Sandy clay'],[8,80,12,'Silt loam'],[20,80,0,'Silt']
  ]) assert.equal(texture(s,l,c).label,name);
  assert.equal(texture(40,40,19.5).warnings.length,1);
  assert.equal(texture(40,40,20.5).warnings.length,1);
  for (const values of [[40,40,19.49],['',40,60],[-1,50,51],['NaN',0,100],['0x28',40,20]]) {
    assert.throws(()=>texture(...values));
  }
});
test('semilog D-values, Cu and Cc match independently worked examples', () => {
  const g = gradation([[4,80],[.25,0],[1,40]]);
  const close = (a,b) => assert.ok(Math.abs(a-b)<1e-12, `${a} differs from ${b}`);
  close(g.d10,Math.sqrt(2)/4);
  close(g.d30,Math.sqrt(2)/2);
  close(g.d60,2);
  close(g.cu,4*Math.sqrt(2));
  close(g.cc,1/Math.sqrt(2));
});
test('cumulative gradation validation and missing or ambiguous diameters', () => {
  assert.equal(gradation([[.075,50],[4.75,100]]).d10,null);
  assert.equal(gradation([[.075,10],[.15,10],[4.75,100]]).d10,null);
  assert.equal(gradation([[.075,10],[4.75,100]]).d10,.075);
  for (const rows of [[[.075,10],[.075,15]],[[.075,15],[4.75,10]],[[.075,-1],[4.75,100]],[[0,0],[4.75,101]]]) {
    assert.throws(()=>gradation(rows));
  }
});
test('retained mass includes pan and reconciles against original dry mass', () => {
  const input = [[4.75,20],[0,2],[.075,28],[.425,50]];
  const g = gradation(input,'mass','mm',100);
  assert.deepEqual(g.curve.map(p=>p.passing),[2,30,80]);
  assert.equal(g.recovered,100);
  assert.equal(g.closure,0);
  assert.equal(screen(gradation(input,'mass','mm',101),null,true,true).reason,'Resolve the mass closure flag.');
  assert.throws(()=>gradation([[.075,28],[.425,50],[4.75,20]],'mass'));
  assert.throws(()=>gradation([[0,0],[.075,0],[4.75,0]],'mass'));
});
test('µm and inch representations preserve standard sieve readings', () => {
  for (const [unit,scale] of [['µm',1000],['in',1/25.4]]) {
    const g = gradation([[.075*scale,8],[4.75*scale,96]],'passing',unit);
    assert.equal(g.p200,8);
    assert.equal(g.p4,96);
  }
});
test('Atterberg limits handle A-line, U-line, LL = 50, NP and invalid values', () => {
  assert.equal(atterberg(30,22.7,'measured').label,'CL');
  assert.equal(atterberg(30,22.71,'measured').label,'ML');
  assert.equal(atterberg(25,21,'measured').label,'CL-ML');
  assert.equal(atterberg(25,18,'measured').label,'CL-ML');
  assert.equal(atterberg(50,25,'measured').label,'CH');
  assert.equal(atterberg(50,30,'measured').label,'MH');
  assert.equal(atterberg(30,2,'measured').aboveU,true);
  assert.equal(atterberg('','','np').pi,null);
  assert.equal(atterberg('','','unknown'),null);
  assert.throws(()=>atterberg(25,26,'measured'));
});
test('USCS thresholds, equal sand/gravel, and required specimen basis', () => {
  const run = (p200,p4,a,extra={})=>screen({p200,p4,cu:6,cc:1,curve:[],closure:null,...extra},a,true,true).symbol;
  const np=atterberg('','','np'), border=atterberg(25,20,'measured'), cl=atterberg(34,20,'measured');
  assert.equal(run(4.99,60,null),'SW');
  assert.equal(run(0,50,null),'SW');
  assert.equal(run(3,35,null,{cu:4,cc:3}),'GW');
  assert.equal(run(3,35,null,{cu:4,cc:3.01}),'GP');
  assert.equal(run(5,60,np),'SW-SM');
  assert.equal(run(12,60,cl),'SW-SC');
  assert.equal(run(12.01,60,cl),'SC');
  assert.equal(run(13,60,border),'SC-SM');
  assert.equal(run(13,20,border),'GC-GM');
  assert.equal(run(49.99,100,np),'SM');
  assert.equal(run(50,null,cl),'CL');
  assert.equal(run(50,null,atterberg(30,2,'measured')),null);
  assert.equal(run(6,100,border),null);
  assert.equal(run(null,100,cl),null);
  assert.equal(run(4,100,null,{cc:null}),null);
  assert.equal(run(13,60,cl,{curve:[{size:75,passing:99}]}),null);
  assert.equal(screen(null,cl,false,true).symbol,null);
  assert.equal(screen(null,cl,true,false).symbol,null);
});
test('CSV supports BOM, CRLF, escaped quotes and embedded newlines', () => {
  assert.deepEqual(parseCSV('\uFEFFid,n\r\n"a,""b""\r\nc",2\r\n'),[['id','n'],['a,"b"\nc','2']]);
  assert.throws(()=>parseCSV('a,b\n1'));
  assert.throws(()=>parseCSV('a,b\n"1,2'));
  assert.throws(()=>parseCSV('a,b\n"1"x,2'));
});

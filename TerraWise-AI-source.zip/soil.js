(function (root) {
  'use strict';
  const number = (value, label, min = 0, max = Infinity) => {
    const n = /^[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[-+]?\d+)?$/i.test(String(value).trim()) ? Number(value) : NaN;
    if (!Number.isFinite(n) || n < min || n > max) {
      throw new Error(`${label} must be a number ${max === Infinity ? `≥ ${min}` : `from ${min} to ${max}`}.`);
    }
    return n;
  };
  const stable = x => Number(x.toPrecision(14));

  function textureClass(s, l, c) {
    if (stable(l + 1.5 * c) < 15) return 'Sand';
    if (stable(l + 2 * c) < 30) return 'Loamy sand';
    if ((c >= 7 && c < 20 && s > 52 && l < 50) || (c < 7 && l < 50)) return 'Sandy loam';
    if (c >= 7 && c < 27 && l >= 28 && l < 50 && s <= 52) return 'Loam';
    if (l >= 80 && c < 12) return 'Silt';
    if (l >= 50 && c < 27) return 'Silt loam';
    if (c >= 20 && c < 35 && l < 28 && s > 45) return 'Sandy clay loam';
    if (c >= 35 && s > 45) return 'Sandy clay';
    if (c >= 27 && c < 40) return s <= 20 ? 'Silty clay loam' : 'Clay loam';
    if (c >= 40 && l >= 40) return 'Silty clay';
    return 'Clay';
  }

  function texture(sand, silt, clay) {
    const raw = [number(sand, 'Sand', 0, 100), number(silt, 'Silt', 0, 100), number(clay, 'Clay', 0, 100)];
    const total = stable(raw.reduce((a, b) => a + b, 0));
    if (Math.abs(total - 100) > 0.5) throw new Error(`Texture totals ${total}%. Enter fractions totaling 100% (±0.5 percentage points).`);
    const fractions = raw.map(n => stable(n * 100 / total));
    return { raw, fractions, total, label: textureClass(...fractions), warnings: total === 100 ? [] :
      [`Input total ${total}% was normalized to 100% before classification.`] };
  }

  function gradation(rows, basis = 'passing', unit = 'mm', initial) {
    if (!['passing', 'mass'].includes(basis) || !['mm', 'µm', 'in'].includes(unit)) throw new Error('Choose a supported input basis and aperture unit.');
    if (rows.length < 2 || rows.length > 1000) throw new Error('Supply between 2 and 1,000 sieve rows.');
    const factor = { mm: 1, 'µm': 0.001, in: 25.4 }[unit];
    const points = rows.map(([size, value], i) => ({
      size: stable(number(size, `Row ${i + 1} aperture`, basis === 'mass' ? 0 : 1e-9 / factor, 1e6 / factor) * factor),
      value: number(value, `Row ${i + 1} ${basis === 'mass' ? 'retained mass' : 'passing'}`, 0, basis === 'mass' ? Infinity : 100)
    })).sort((a, b) => a.size - b.size);
    if (points.some(p => p.size > 0 && p.size < 1e-9)) throw new Error('A positive aperture must be at least 0.000000001 mm.');
    if (points.some((p, i) => i && p.size === points[i - 1].size)) throw new Error('Each aperture must be unique.');
    const warnings = [];
    let recovered = null, closure = null, original = null;
    if (basis === 'mass') {
      if (points[0].size !== 0 || points.length < 3) throw new Error('Include two positive apertures and the pan as aperture 0.');
      recovered = stable(points.reduce((sum, point) => sum + point.value, 0));
      if (!recovered || !Number.isFinite(recovered)) throw new Error('Total recovered mass must be finite and positive.');
      if (String(initial ?? '').trim()) {
        original = number(initial, 'Initial dry mass', 1e-12);
        closure = stable(100 * (recovered / original - 1));
        if (!Number.isFinite(closure)) throw new Error('Mass closure is out of range.');
        if (Math.abs(closure) > 0.3) warnings.push(`Mass closure differs by ${closure.toFixed(2)}%. USCS is withheld pending review (demo threshold ±0.3%).`);
      } else warnings.push('Initial dry mass omitted. Mass closure could not be checked.');
      let finerMass = 0;
      for (const point of points) {
        point.passing = stable(100 * (finerMass / recovered));
        finerMass += point.value;
      }
    } else {
      for (const point of points) point.passing = point.value;
      if (points.some((p, i) => i && p.passing < points[i - 1].passing)) throw new Error('Cumulative passing must increase or stay constant as aperture increases.');
      warnings.push('Cumulative passing supplied directly. Mass closure is unavailable.');
    }
    const curve = points.filter(p => p.size > 0);
    const diameter = target => {
      const exact = curve.filter(p => p.passing === target);
      if (exact.length) return exact.length === 1 ? exact[0].size : null;
      const i = curve.findIndex(p => p.passing > target);
      if (i < 1) return null;
      const a = curve[i - 1], b = curve[i];
      return Math.exp(Math.log(a.size) + Math.log(b.size / a.size) * (target - a.passing) / (b.passing - a.passing));
    };
    const [d10, d30, d60] = [10, 30, 60].map(diameter);
    if ([d10, d30, d60].includes(null)) warnings.push('At least one D-value is unbracketed or lies on a plateau. Those values are withheld.');
    const measured = size => curve.find(p => p.size === size)?.passing ?? null;
    return { points, curve, d10, d30, d60, cu: d10 && d60 ? d60 / d10 : null,
      cc: d10 && d30 && d60 ? (d30 / d10) * (d30 / d60) : null,
      p4: measured(4.75), p200: measured(0.075), recovered, closure, original, basis, warnings };
  }

  function atterberg(ll, pl, state) {
    if (state === 'unknown') return null;
    if (state === 'np') return { label: 'ML', pi: null, ll: null, pl: null, a: null, np: true, warnings: [] };
    ll = number(ll, 'Liquid limit', 1e-12, 1000);
    pl = number(pl, 'Plastic limit', 0, ll);
    const pi = stable(ll - pl), a = stable(0.73 * (ll - 20));
    const warnings = [];
    if (pi === 0) warnings.push('LL equals PL. Verify whether the laboratory intended to report NP.');
    const aboveU = pi > Math.max(0, stable(0.9 * (ll - 8)));
    if (aboveU) warnings.push('Point plots above the empirical U-line. Verify the lab data before using the screening symbol.');
    const label = ll >= 50 ? (pi >= a ? 'CH' : 'MH') :
      pi < 4 || pi < a ? 'ML' : pi <= 7 ? 'CL-ML' : 'CL';
    return { ll, pl, pi, a, label, aboveU, warnings };
  }

  function screen(g, a, mineral, basisConfirmed) {
    const pending = reason => ({ symbol: null, reason });
    if (!mineral) return pending('Confirm the specimen is inorganic. Organic soils and peat are outside this screen.');
    if (!basisConfirmed) return pending('Confirm the gradation is on the fraction passing 75 mm.');
    if (!g) return pending('A valid gradation is required.');
    if (g.closure !== null && Math.abs(g.closure) > 0.3) return pending('Resolve the mass closure flag.');
    if (g.curve.some(p => p.size >= 75 && p.passing < 100)) return pending('Gradation indicates oversize material. Recompute on the fraction passing 75 mm.');
    if (g.p200 === null) return pending('Add a measured 0.075 mm (No. 200) value.');
    const usableLimits = a && !a.aboveU && (a.np || a.pi > 0);
    if (g.p200 >= 50) return usableLimits ? { symbol: a.label, reason: 'At least 50% passes 0.075 mm. Plasticity determines the inorganic group.' } :
      pending('Fine-grained specimen. Supply usable Atterberg limits or a laboratory NP result.');
    if (g.p4 === null) return pending('Add a measured 4.75 mm (No. 4) value for coarse material.');
    const prefix = stable(100 - g.p4) > stable(g.p4 - g.p200) ? 'G' : 'S';
    const clean = g.cu !== null && g.cc !== null ?
      prefix + (stable(g.cu) >= (prefix === 'G' ? 4 : 6) && stable(g.cc) >= 1 && stable(g.cc) <= 3 ? 'W' : 'P') : null;
    if (g.p200 < 5) return clean ? { symbol: clean, reason: 'Less than 5% fines. Cu and Cc determine grading.' } :
      pending('Clean coarse specimen. D10, D30 and D60 are required to assess grading.');
    if (!usableLimits) return pending('Supply usable Atterberg limits or a laboratory NP result to classify the fines.');
    if (a.label === 'CL-ML') return g.p200 > 12 ? { symbol: `${prefix}C-${prefix}M`, reason: 'More than 12% fines with borderline CL-ML plasticity.' } :
      pending('Fines are in both the 5–12% band and the CL-ML plasticity zone. Review the applicable standard and laboratory record.');
    const fines = prefix + (a.label.startsWith('C') ? 'C' : 'M');
    if (g.p200 > 12) return { symbol: fines, reason: 'More than 12% fines. Plasticity determines the fines suffix.' };
    return clean ? { symbol: `${clean}-${fines}`, reason: '5–12% fines inclusive. Grading and fines plasticity determine the dual symbol.' } :
      pending('5–12% fines. The dual symbol requires all three D-values.');
  }

  function parseCSV(source) {
    const text = source.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
    const rows = [];
    let row = [], value = '', mode = 'plain';
    function push() { row.push(value.trim()); value = ''; mode = 'plain'; }
    for (let i = 0; i <= text.length; i++) {
      const char = text[i] ?? '\n';
      if (mode === 'quoted') {
        if (char !== '"') value += char;
        else if (text[i + 1] === '"') { value += '"'; i++; }
        else mode = 'closed';
      } else if (char === ',' || char === '\n') {
        push();
        if (char === '\n') { if (row.some(Boolean)) rows.push(row); row = []; }
      } else if (mode === 'closed') {
        if (char !== ' ' && char !== '\t') throw new Error('Unexpected text after closing CSV quote.');
      } else if (char === '"') {
        if (value.trim()) throw new Error('Unexpected CSV quote.');
        value = '';
        mode = 'quoted';
      } else value += char;
    }
    if (mode === 'quoted') throw new Error('Unclosed CSV quote.');
    if (rows.length < 2) throw new Error('CSV must contain a header and at least one data row.');
    if (rows.some(row => row.length !== rows[0].length)) throw new Error('CSV rows must have the same number of columns as the header.');
    return rows;
  }
  function parseRecord(text) {
    let record;
    try { record = JSON.parse(text); }
    catch { throw new Error('Choose a valid TerraWise specimen JSON file.'); }
    if (record?.format !== 'terrawise-specimen' || record.version !== 1) {
      throw new Error('This file is not a supported TerraWise specimen record (version 1).');
    }
    const { specimen, origin, inputs } = record;
    const inputString = value => typeof value === 'string' && value.length <= 40 &&
      (value === '' || /^-?(?:\d+(?:\.\d+)?|\.\d+)(?:e[+-]?\d+)?$/i.test(value) && Number.isFinite(Number(value)));
    const fields = (values, count) => Array.isArray(values) && values.length === count && values.every(inputString);
    if (typeof specimen !== 'string' || specimen.length > 100 || /[\r\n]/.test(specimen) ||
        !['sample','manual','imported','mixed'].includes(origin) || !inputs ||
        !fields(inputs.texture, 3) || !Array.isArray(inputs.rows) || inputs.rows.length > 1000 ||
        !inputs.rows.every(row => fields(row, 2)) || !fields([inputs.initial, inputs.ll, inputs.pl], 3) ||
        !['passing','mass'].includes(inputs.basis) || !['mm','µm','in'].includes(inputs.unit) ||
        !['measured','np','unknown'].includes(inputs.limits) ||
        typeof inputs.mineral !== 'boolean' || typeof inputs.confirmed !== 'boolean') {
      throw new Error('The specimen file has missing or malformed inputs.');
    }
    return { specimen, origin, inputs };
  }

  const methods = { texture, textureClass, gradation, atterberg, screen, parseCSV, parseRecord };
  if (typeof module !== 'undefined') module.exports = methods;
  else root.Soil = methods;
})(globalThis);

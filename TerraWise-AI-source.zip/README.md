# TerraWise AI

TerraWise AI is a local demonstration workspace for agricultural soil texture and preliminary geotechnical screening. The four built-in datasets are synthetic. The app keeps the current workspace in browser memory. Export results before closing or refreshing the page.

## Run the demo

Open `index.html` from this folder in a modern browser. The calculations, charts, uploads and report exports work offline, with no installation. The separate `TerraWise-AI.html` download bundles the same browser app into a single file.

For the optional local server, run `node server.mjs` in this directory with Node.js 22 or newer, then open http://127.0.0.1:4173. Use `TERRAWISE_PORT` to change the port.

## Import CSV data

Use comma separators, decimal points and the exact header order shown below. Files must be under 1 MiB and contain at most 1,000 data rows. The in-app template buttons generate examples.

| Workflow | Header | Data basis |
| --- | --- | --- |
| Texture | `sample_id,sand_pct,silt_pct,clay_pct` | One specimen per row, unique IDs, USDA mineral fine-earth basis |
| Sieve passing | `aperture_mm,passing_pct` | One sieve per row, one specimen per file, cumulative dry-mass percent passing |
| Sieve mass | `aperture_mm,retained_g` | Individual dry grams retained per sieve, with aperture 0 for the pan |

Use `aperture_um` or `aperture_in` in place of `aperture_mm` for micrometres or inches. Sieve outputs use mm. Sieve uploads clear previous plasticity and specimen confirmations. If importing both example files, select TW-04 from the texture file, upload the sieve file, choose laboratory NP for the synthetic sample, then check both specimen confirmations. The expected screen is SP-SM.

The HTML report records inputs, units, plots, calculation outputs, quality flags and any model draft. Use **Print / PDF** for the browser print dialog or print the downloaded report. The results CSV is a compact, one-metric-per-row summary.

## Optional AI drafts

Start [Ollama](https://docs.ollama.com/api/generate) locally with a local model already installed. Set `TERRAWISE_OLLAMA_MODEL` to the model name and start the Node server. In PowerShell:

```powershell
$env:TERRAWISE_OLLAMA_MODEL = 'your-installed-model'
node server.mjs
```

Open the printed loopback address and choose **Generate AI draft**. This sends calculated metrics and generated quality messages to the configured local model on demand. The workspace excludes raw uploaded files and specimen identifiers from the prompt. The model has no role in computing or changing results. **Download AI prompt** is available offline. Expert review is required before using draft interpretations.

## Calculation scope

- Texture implements the 12 USDA primary mineral fine-earth classes. Totals within ±0.5 percentage points are normalized and flagged. Use measured sand, silt and clay fractions on the appropriate particle-size basis.
- Gradation uses measured passing or recovered dry mass, with optional mass-closure comparison. The ±0.3% closure threshold is a demo quality rule. D-values use semi-log interpolation, with unavailable values shown when unbracketed or ambiguous. USCS uses measured values at the nominal sieve openings when required. For inch inputs, use the exact metric-equivalent aperture, or select mm for nominal sieve sizes.
- USCS is a preliminary screen for inorganic material on a passing-75-mm basis. Organic groups, peat, descriptive modifiers, and the combination of 5–12% fines with CL-ML plasticity require separate review. Verify design, acceptance and specification decisions against the governing standard, original lab data and qualified engineering judgment.

References are the [USDA NRCS Soil Survey Manual, Chapter 3](https://www.nrcs.usda.gov/sites/default/files/2022-09/SSM-ch3.pdf), [FHWA Geotechnical Aspects of Pavements, Table 4-13](https://www.fhwa.dot.gov/engineering/geotech/pubs/05037/04c.cfm), and [ASTM D2487](https://store.astm.org/standards/d2487).

## Source and verification

- `soil.js` contains deterministic calculations and CSV parsing.
- `app.js`, `index.html` and `styles.css` contain the browser interface and exports.
- `server.mjs` serves the browser app and optionally connects to Ollama.
- Run `node soil.test.cjs` for the reference compositions, method boundaries, known interpolation outputs, mass closure, unit conversions, screening gates and CSV checks.
- Browser checks covered four sample datasets, numeric validation, unit conversion, both CSV imports, HTML and CSV exports, and a 390 px viewport. The optional model path requires an installed model.
